import { describe, it, expect } from 'vitest'

describe('sample test', () => {
  it('test sample', () => {
    expect(5).toBe(5)
  })
})
