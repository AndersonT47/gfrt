export function bootstrap(environment, logger) {
  global.environment = environment
  global.logger = logger
}
