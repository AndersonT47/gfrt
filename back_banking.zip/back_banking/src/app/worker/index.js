import App from '@elasticmind/ada/src/app/app.js'
import Worker from '@elasticmind/ada/src/app/worker/worker.js'

(async () => {
  const app = new App()
  await app.bootstrap('Elasticmind Worker')
  await app.run(new Worker())
})()
