import http from 'node:http'
import url from 'node:url'
import crypto from 'node:crypto'
import path from 'node:path'
import fastify from 'fastify'
import cors from '@fastify/cors'
import helmet from '@fastify/helmet'
import prometheusClient from 'prom-client'
import { glob } from 'glob'
import { createHttpTerminator } from 'http-terminator'
import { Logger } from '#core/logging/index.js'
import { Config } from '#core/config/index.js'
import {
  correlationIdMiddleware,
  requestLoggingMiddleware,
  responseLoggingMiddleware,
  swaggerMiddleware,
  shareRequestContextMiddleware
} from './middlewares/index.js'

const requestIdHeaderName = 'x-request-id'

export class ApiServer {
  #isReady = false
  #fastify = undefined
  #server = undefined
  #registerBeforeStartHookCallback = undefined

  async #mountMiddlewares() {
    if (Config.get('app.api.server.cors.enabled')) {
      this.#fastify?.register(cors)
    }
    this.#fastify?.register(helmet, { contentSecurityPolicy: false })

    requestLoggingMiddleware(this.#fastify)
    responseLoggingMiddleware(this.#fastify)
    correlationIdMiddleware(this.#fastify)
    shareRequestContextMiddleware(this.#fastify)
  }

  async #mountRoutes() {
    await this.#mountHealthRoute()
    await this.#mountMetricsRoute()
    await this.#autoMountFeatureRoutes()
  }

  async #mountHealthRoute() {
    this.#fastify.get('/health', async (_req, reply) => {
      if (!this.#isReady) return reply.status(503).send('Server shutting down')

      return reply.send('Healthy')
    })
  }

  async #mountMetricsRoute() {
    const registry = new prometheusClient.Registry()
    prometheusClient.collectDefaultMetrics({ register: registry })

    this.#fastify.get('/metrics', async (_req, reply) => {
      const metrics = await registry.metrics()
      reply.header('Content-Type', registry.contentType)
      return reply.send(metrics)
    })
  }

  async #mountSwaggerRoute() {
    if (Config.get('app.api.server.swagger.enabled')) {
      await swaggerMiddleware(this.#fastify)
    }
  }

  async #autoMountFeatureRoutes() {
    await this.#mountSwaggerRoute()

    const routePattern = path.resolve(path.dirname(''), 'src', 'features', '**/*router.js')
    const files = await glob(routePattern, { windowsPathsNoEscape: true })

    for (const file of files) {
      const urlRouter = url.pathToFileURL(file)
      const routes = await import(urlRouter)
      this.#fastify.route(routes.default)
    }
  }

  async #bootstrap() {
    Logger.info('Bootstrapping application')

    const serverFactory = (handler, opts) => {
      this.#server = http.createServer((req, res) => {
        handler(req, res)
      })
      return this.#server
    }

    this.#fastify = fastify({
      serverFactory,
      logger: Logger.current,
      disableRequestLogging: true,
      requestIdLogLabel: requestIdHeaderName,
      genReqId: () => {
        const randomBytes = crypto.randomBytes(12)
        return randomBytes.toString('hex')
      }
    })

    await this.#mountMiddlewares()
    await this.#mountRoutes()

    if (this.#registerBeforeStartHookCallback && typeof this.#registerBeforeStartHookCallback === 'function') {
      await this.#registerBeforeStartHookCallback(this.#fastify)
    }

    this.#isReady = true
  }

  fastify() {
    return this.#fastify
  }

  registerBeforeStartHook(callback) {
    this.#registerBeforeStartHookCallback = callback
  }

  async launch() {
    await this.#bootstrap()

    const port = Config.get('app.api.server.port')

    const onError = (error) => {
      if (error.syscall !== 'listen') throw error

      throw error
    }

    const onListening = () => {
      const address = this.#server.address()
      Logger.info('Server started on ' + address.address + ':' + Config.get('app.api.server.port'))
    }

    this.#fastify.addHook('onReady', () => {
      if (Config.get('app.api.server.swagger.enabled')) {
        this.#fastify.swagger()
      }
    })

    this.#fastify.ready(() => {
      this.#server.listen({ port, host: '0.0.0.0' })
    })

    this.#server.on('error', onError)
    this.#server.on('listening', onListening)

    const unhandledRejectionHandler = (reason) => {
      Logger.error('Unhandled Promise Rejection: err: ', reason.message)
      Logger.error(reason.stack)
    }

    const shutdownHandler = async () => {
      Logger.info('Server received shutdown signal')
      this.#isReady = false
      Logger.info('Waiting for open connections to be finished')
      const httpTerminator = createHttpTerminator({ server: this.#server })
      await httpTerminator.terminate()
      Logger.info('Server is closed')
      process.exit(0)
    }

    process.on('unhandledRejection', unhandledRejectionHandler)
    process.on('SIGINT', shutdownHandler)
    process.on('SIGTERM', shutdownHandler)
  }
}
