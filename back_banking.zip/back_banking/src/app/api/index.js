import { App } from '#src/app/app.js'
import { ApiServer } from './apiServer.js'

import { enrichHttpRequestWithSession } from './middlewares/enrichHttpRequestWithSession.js'

(async () => {
  const app = new App()
  await app.bootstrap('SafraLink Banking Module API Server')

  const server = new ApiServer()
  server.registerBeforeStartHook(() => {
    const fastify = server.fastify()

    enrichHttpRequestWithSession(fastify)
  })

  await app.run(server)
})()
