import { hrtime } from 'node:process'
import { useTry } from '#core/hooks/index.js'

const correlationIdHeaderName = 'x-correlation-id'

const filterLoggingRoutes = ['/health', '/metrics', '/swagger']

const matchRoute = (route) => {
  return filterLoggingRoutes.find(routeOption => route?.includes(routeOption))
}

export function requestLoggingMiddleware(fastifyInstance) {
  fastifyInstance.addHook('onRequest', (request, reply, done) => {
    if (!matchRoute(request.routeOptions.url)) {
      const startTime = hrtime.bigint()
      request.startTime = startTime
      request.log.info({
        method: request.method,
        url: request.raw.url,
        correlationId: request.headers[correlationIdHeaderName],
        headers: request.headers,
        hostname: request.hostname,
        remoteAddress: request.ip,
        remotePort: request.socket?.remotePort,
        startTime: startTime
      }, 'Request received (CorrelationId: ' + request.headers[correlationIdHeaderName] + ')')
    }
    done()
  })

  fastifyInstance.addHook('preHandler', (request, reply, done) => {
    if (!matchRoute(request.routeOptions.url)) {
      if (request.body) {
        request.log.info({
          body: request.body
        }, 'Request body (CorrelationId: ' + request.headers[correlationIdHeaderName] + ')')
      }
    }
    done()
  })
}

export function responseLoggingMiddleware(fastifyInstance) {
  fastifyInstance.addHook('onResponse', (request, reply, done) => {
    if (!matchRoute(request.routeOptions.url)) {
      request.log.info({
        method: request.method,
        url: request.raw.url,
        correlationId: reply.getHeader(correlationIdHeaderName),
        statusCode: reply.raw.statusCode,
        headers: reply.getHeaders(),
        body: reply.raw.body || undefined,
        durationMs: reply.getResponseTime()
      }, 'Response sent (CorrelationId: ' + request.headers[correlationIdHeaderName] + ')')
    }
    done()
  })

  fastifyInstance.addHook('onSend', async (request, reply, payload) => {
    if (!matchRoute(request.routeOptions.url)) {
      if (payload) {
        const [error, parsedPayload] = await useTry(async () => {
          return JSON.parse(payload)
        })
        const responseBody = error ? payload?.toString() : parsedPayload
        request.log.info({
          body: responseBody
        }, 'Response body (CorrelationId: ' + request.headers[correlationIdHeaderName] + ')')
      }
    }
  })
}
