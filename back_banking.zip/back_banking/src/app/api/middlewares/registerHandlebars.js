import { fastifyView } from '@fastify/view'
import handlebars from 'handlebars'

export function registerHandlebars(fastify) {
  fastify.register(fastifyView, {
    engine: { handlebars },
    includeViewExtension: true
  })
}
