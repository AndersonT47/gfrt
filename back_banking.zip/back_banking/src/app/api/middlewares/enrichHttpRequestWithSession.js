import { useTry } from '#core/hooks/index.js'

const sessionHeaderKeyName = 'x-session'

export function enrichHttpRequestWithSession(fastify) {
  fastify.addHook('preHandler', async (request, _) => {
    const contextBase64 = request.headers[sessionHeaderKeyName]

    if (contextBase64) {
      const parse = async () => {
        const contextJson = Buffer.from(contextBase64, 'base64').toString('ascii')
        const session = JSON.parse(contextJson)
        return session
      }

      const [err, result] = await useTry(() => parse())

      if (!err) {
        request.session = {
          ...result
        }
      }
    }
  })
}
