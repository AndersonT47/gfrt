import fastifySwagger from '@fastify/swagger'
import fastifySwaggerUI from '@fastify/swagger-ui'
import { Config } from '#core/config/index.js'

export async function swaggerMiddleware(fastifyInstance) {
  const swaggerConfig = Config.get('app.api.server.swagger')

  await fastifyInstance.register(fastifySwagger, {
    openapi: {
      info: {
        title: swaggerConfig.title,
        description: swaggerConfig.description,
        version: swaggerConfig.version
      },
      schemes: ['http', 'https'],
      consumes: ['application/json'],
      produces: ['application/json'],
      components: {
        securitySchemes: {
          apiKey: {
            type: 'apiKey',
            name: 'apiKey',
            in: 'header',
            schemeLabel: 'apiKey'
          },
          bearerAuth: {
            type: 'http',
            scheme: 'bearer',
            bearerFormat: 'JWT',
            schemeLabel: 'bearerAuth'
          }
        }
      }
    },
    exposeRoute: true
  })

  await fastifyInstance.register(fastifySwaggerUI, {
    routePrefix: swaggerConfig.routePrefix,
    uiConfig: {
      docExpansion: 'full',
      deepLinking: false
    },
    uiHooks: {
      onRequest: function (request, reply, done) {
        done()
      },

      preHandler: function (request, reply, done) {
        done()
      }
    },
    staticCSP: true,
    transformStaticCSP: (header) => header,
    transformSpecification: (document, request, reply) => {
      return document
    },
    transformSpecificationClone: true
  })
}
