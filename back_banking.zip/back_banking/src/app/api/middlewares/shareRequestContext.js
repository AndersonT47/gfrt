import { Config } from '#core/config/index.js'
import { initContext } from '#core/hooks/index.js'

const requestIdHeaderName = 'x-request-id'
const correlationIdHeaderName = 'x-correlation-id'

export function shareRequestContextMiddleware(server) {
  if (Config.get('app.api.server.shareRequestContext.enabled')) {
    server.addHook('onRequest', (request, reply, done) => {
      initContext(context => {
        context.headers = request.headers
        context.requestId = request.headers[requestIdHeaderName]
        context.correlationId = request.headers[correlationIdHeaderName]
      })
      done()
    })
  }
}
