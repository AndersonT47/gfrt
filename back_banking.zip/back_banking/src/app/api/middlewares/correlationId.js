import crypto from 'node:crypto'

const requestIdHeaderName = 'x-request-id'
const correlationIdHeaderName = 'x-correlation-id'

const generateNewId = () => {
  const randomBytes = crypto.randomBytes(12)
  return randomBytes.toString('hex')
}

export function correlationIdMiddleware(fastifyInstance) {
  fastifyInstance.addHook('onRequest', (request, reply, done) => {
    request.headers[correlationIdHeaderName] = request.headers[correlationIdHeaderName] || generateNewId()
    done()
  })

  fastifyInstance.addHook('preHandler', (request, reply, done) => {
    reply.header(requestIdHeaderName, request.id)
    reply.header(correlationIdHeaderName, request.headers[correlationIdHeaderName])
    done()
  })
}
