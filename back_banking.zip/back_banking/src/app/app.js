import cfonts from 'cfonts'
import { Config } from '#core/config/index.js'
import { bootstrap } from '#src/bootstrap.js'

export class App {
  async bootstrap(arg) {
    cfonts.say(arg)
    const configInstance = new Config(process.env.NODE_ENV)
    const configBootstrapResult = await configInstance.bootstrap()
    const loggerInstance = configInstance.logger()

    bootstrap(configBootstrapResult, loggerInstance)
  }

  async run(launcher) {
    await launcher.launch()
  }
}
