import { Result } from '#core/features/index.js'
import { useTry } from '#core/hooks/index.js'
import { getIdtUser } from '#models/legacy/validateCifByUserId.js'
import * as Nicknames from '#models/legacy/accountNicknames.js'

export default class GetNicknamesUseCase {
  async execute({ userId, cif, cifRequested, type }) {
    const [errValidateCif, validateCif] = await useTry(() => getIdtUser(userId, cif, cifRequested))

    if (errValidateCif) {
      return Result.fail({
        code: 500,
        error: errValidateCif.name,
        message: errValidateCif.message
      })
    }

    if (!validateCif || validateCif.IdtUser === '') {
      return Result.fail({
        code: 401,
        error: 'Unauthorized',
        message: 'User without permission for this cif.'
      })
    }

    const [errAccounts, accounts] = await useTry(() => this.#getAccountNicknames(cifRequested, type))

    if (errAccounts) {
      return Result.fail({
        code: 500,
        error: errAccounts.name,
        message: errAccounts.message
      })
    }

    return Result.ok({
      code: 200,
      value: {
        nicknames: accounts
      }
    })
  }

  async #getAccountNicknames(cif, type) {
    if (!type) {
      const accountsCD = await Nicknames.findAccountsCDByCif(cif)
      const nicknamesCD = {
        acctType: 'CD',
        accounts: accountsCD
      }

      const accountsDD = await Nicknames.findAccountsDDByCif(cif)
      const nicknamesDD = {
        acctType: 'DD',
        accounts: accountsDD
      }

      const accountsFC = await Nicknames.findAccountsFCByCif(cif)
      const nicknamesFC = {
        acctType: 'FC',
        accounts: accountsFC
      }

      const accountsFX = await Nicknames.findAccountsFXByCif(cif)
      const nicknamesFX = {
        acctType: 'FX',
        accounts: accountsFX
      }

      const accountsLN = await Nicknames.findAccountsLNByCif(cif)
      const nicknamesLN = {
        acctType: 'LN',
        accounts: accountsLN
      }

      const accountsLC = await Nicknames.findAccountsLCByCif(cif)
      const nicknamesLC = {
        acctType: 'LC',
        accounts: accountsLC
      }

      const accountsSC = await Nicknames.findAccountsSCByCif(cif)
      const nicknamesSC = {
        acctType: 'SC',
        accounts: accountsSC
      }

      const accountsBK = await Nicknames.findAccountsBKByCif(cif)
      const nicknamesBK = {
        acctType: 'BK',
        accounts: accountsBK
      }

      return [
        nicknamesCD,
        nicknamesDD,
        nicknamesFC,
        nicknamesFX,
        nicknamesLN,
        nicknamesLC,
        nicknamesSC,
        nicknamesBK
      ]
    }

    if (type === 'CD') {
      const accountsCD = await Nicknames.findAccountsCDByCif(cif)
      return [{
        acctType: 'CD',
        accounts: accountsCD
      }]
    }

    if (type === 'DD') {
      const accountsDD = await Nicknames.findAccountsDDByCif(cif)
      const nicknamesDD = {
        acctType: 'DD',
        accounts: accountsDD
      }

      const accountsCD = await Nicknames.findAccountsCDByCif(cif)
      const nicknamesCD = {
        acctType: 'CD',
        accounts: accountsCD
      }

      return [
        nicknamesDD,
        nicknamesCD
      ]
    }

    if (type === 'FC') {
      const accountsFC = await Nicknames.findAccountsFCByCif(cif)
      return [{
        acctType: 'FC',
        accounts: accountsFC
      }]
    }

    if (type === 'FX') {
      const accountsFX = await Nicknames.findAccountsFXByCif(cif)
      return [{
        acctType: 'FX',
        accounts: accountsFX
      }]
    }

    if (type === 'LN') {
      const accountsLN = await Nicknames.findAccountsLNByCif(cif)
      return [{
        acctType: 'LN',
        accounts: accountsLN
      }]
    }

    if (type === 'LC') {
      const accountsLC = await Nicknames.findAccountsLCByCif(cif)
      return [{
        acctType: 'LC',
        accounts: accountsLC
      }]
    }

    if (type === 'SC') {
      const accountsSC = await Nicknames.findAccountsSCByCif(cif)
      return [{
        acctType: 'SC',
        accounts: accountsSC
      }]
    }

    if (type === 'BK') {
      const accountsBK = await Nicknames.findAccountsBKByCif(cif)
      return [{
        acctType: 'BK',
        accounts: accountsBK
      }]
    }
  }
}
