import handler from './endpoint.js'

const schema = {
  description: 'Get Nickname',
  tags: ['Nickname'],
  summary: '',
  params: {
    type: 'object',
    properties: {},
    required: []
  },
  queryString: {
    type: 'object',
    properties: {
      id: { type: 'string' },
      type: { type: 'string' }
    },
    required: ['id']
  },
  response: {
    200: {
      type: 'object',
      properties: {
        code: { type: 'integer' },
        message: { type: 'string' },
        data: {
          type: 'object',
          properties: {
            nicknames: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  acctType: { type: 'string' },
                  accounts: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        accountNumber: { type: 'string' },
                        accountNickname: { type: 'string' },
                        accountDescription: { type: 'string' },
                        acctType: { type: 'string' },
                        accountBkType: { type: 'string' }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    500: {
      type: 'object',
      properties: {
        code: { type: 'integer' },
        message: { type: 'string' },
        error: { type: 'string' }
      }
    }
  }
}

export default {
  method: 'GET',
  url: '/banking/v1/accounts/nicknames',
  schema,
  handler
}
