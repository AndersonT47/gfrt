import GetNicknamesUseCase from './useCase.js'
import { UseCaseHandler } from '#core/features/index.js'

export default async function getNicknamesEndpoint(request, reply) {
  const { userId, cif } = request?.session?.userContext
  const cifRequested = Buffer.from(request?.query?.id, 'base64').toString()
  const type = request?.query?.type

  const useCase = new GetNicknamesUseCase()
  const result = await UseCaseHandler.dispatch(useCase, { userId, cif, cifRequested, type })

  return reply
    .status(result.code)
    .send(result.toApiResponse())
}
