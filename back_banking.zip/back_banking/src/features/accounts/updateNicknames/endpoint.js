import UpdateNicknamesUseCase from './useCase.js'
import { UseCaseHandler } from '#core/features/index.js'

export default async function updateNicknamesEndpoint(request, reply) {
  const { userId, cif } = request?.session?.userContext
  const { body } = request
  const cifRequested = Buffer.from(body?.nicknames?.id, 'base64').toString()

  const useCase = new UpdateNicknamesUseCase()
  const result = await UseCaseHandler.dispatch(useCase, { userId, cif, cifRequested, body })

  return reply
    .status(result.code)
    .send(result.toApiResponse())
}
