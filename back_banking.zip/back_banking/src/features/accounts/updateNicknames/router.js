import handler from './endpoint.js'

const schema = {
  description: 'Update Nickname',
  tags: ['Nickname'],
  summary: '',
  params: {
    type: 'object',
    properties: {},
    required: []
  },
  body: {
    nicknames: {
      type: 'object',
      properties: {
        id: { type: 'string' },
        accounts: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              accountNumber: { type: 'string' },
              accountNickname: { type: 'string' },
              acctType: { type: 'string' }
            }
          }
        }
      }
    }
  },
  response: {
    200: {
      type: 'object',
      properties: {
        code: { type: 'integer' },
        message: { type: 'string' },
        data: {
          type: 'object'
        }
      }
    },
    500: {
      type: 'object',
      properties: {
        code: { type: 'integer' },
        message: { type: 'string' },
        error: { type: 'string' }
      }
    }
  }
}

export default {
  method: 'POST',
  url: '/banking/v1/accounts/nicknames',
  schema,
  handler
}
