import { Result } from '#core/features/index.js'
import { useTry } from '#core/hooks/index.js'
import { getIdtUser } from '#models/legacy/validateCifByUserId.js'
import * as Nicknames from '#models/accountNickname.js'
import * as NicknamesProcs from '#models/legacy/accountNicknames.js'

export default class UpdateNicknamesUseCase {
  async execute({ userId, cif, cifRequested, body }) {
    const [errValidateCif, validateCif] = await useTry(() => getIdtUser(userId, cif, cifRequested))

    if (errValidateCif) {
      return Result.fail({
        code: 500,
        error: errValidateCif.name,
        message: errValidateCif.message
      })
    }

    if (!validateCif || validateCif.IdtUser === '') {
      return Result.fail({
        code: 401,
        error: 'Unauthorized',
        message: 'User without permission for this cif.'
      })
    }

    const [errValidateAccounts, validateAccounts] = await useTry(() => this.#validateAccounts(body?.nicknames?.accounts, cifRequested))

    if (errValidateAccounts) {
      return Result.fail({
        code: 500,
        error: errValidateAccounts.name,
        message: errValidateAccounts.message
      })
    }

    if (!validateAccounts) {
      return Result.fail({
        code: 401,
        error: 'Unauthorized',
        message: 'User without permission for this account.'
      })
    }

    const [errCreateOrUpdateNickname] = await useTry(() => this.#createOrUpdate(body?.nicknames?.accounts))

    if (errCreateOrUpdateNickname) {
      return Result.fail({
        code: 500,
        error: errCreateOrUpdateNickname.name,
        message: errCreateOrUpdateNickname.message
      })
    }

    return Result.ok({
      code: 200,
      message: 'OK'
    })
  }

  async #validateAccounts(accounts, cif) {
    for (const account of accounts) {
      if (account.acctType === 'CD') {
        const accountsCD = await NicknamesProcs.findAccountsCDByCif(cif)
        const validAccount = accountsCD.some(x => x.accountNumber === account.accountNumber)
        if (!validAccount) {
          return false
        }
      }

      if (account.acctType === 'DD') {
        const accountsDD = await NicknamesProcs.findAccountsDDByCif(cif)
        const validAccount = accountsDD.some(x => x.accountNumber === account.accountNumber)
        if (!validAccount) {
          return false
        }
      }

      if (account.acctType === 'FC') {
        const accountsFC = await NicknamesProcs.findAccountsFCByCif(cif)
        const validAccount = accountsFC.some(x => x.accountNumber === account.accountNumber)
        if (!validAccount) {
          return false
        }
      }

      if (account.acctType === 'FX') {
        const accountsFX = await NicknamesProcs.findAccountsFXByCif(cif)
        const validAccount = accountsFX.some(x => x.accountNumber === account.accountNumber)
        if (!validAccount) {
          return false
        }
      }

      if (account.acctType === 'LN') {
        const accountsLN = await NicknamesProcs.findAccountsLNByCif(cif)
        const validAccount = accountsLN.some(x => x.accountNumber === account.accountNumber)
        if (!validAccount) {
          return false
        }
      }

      if (account.acctType === 'LC') {
        const accountsLC = await NicknamesProcs.findAccountsLCByCif(cif)
        const validAccount = accountsLC.some(x => x.accountNumber === account.accountNumber)

        if (!validAccount) {
          return false
        }
      }

      if (account.acctType === 'SC') {
        const accountsSC = await NicknamesProcs.findAccountsSCByCif(cif)
        const validAccount = accountsSC.some(x => x.accountNumber === account.accountNumber)
        if (!validAccount) {
          return false
        }
      }

      if (account.acctType === 'BK') {
        const accountsBK = await NicknamesProcs.findAccountsBKByCif(cif)
        const validAccount = accountsBK.some(x => x.accountNumber === account.accountNumber)
        if (!validAccount) {
          return false
        }
      }
    }
    return true
  }

  async #createOrUpdate(accounts) {
    for (const account of accounts) {
      const nickname = await Nicknames.findByNickname(account)

      if (nickname) {
        account.ID = nickname.ID

        if (account.accountNickname.trim() === '') {
          account.accountNickname = ''
        }

        await Nicknames.updateNickname(account)
      } else {
        await Nicknames.createNickname(account)
      }
    }
  }
}
