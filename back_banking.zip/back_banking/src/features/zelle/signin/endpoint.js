import { UseCaseHandler } from '#core/features/index.js'
import SigninUseCase from './useCase.js'

export default async function signinEndpoint(request, reply) {
  const { userId, accounts, email, firstName, lastName, ipAddress } = request.body

  const useCase = new SigninUseCase()
  const result = await UseCaseHandler.dispatch(useCase, {
    userId,
    accounts,
    email,
    firstName,
    lastName,
    ipAddress
  })


  
  return reply
    .status(result.code)
    .send(result.toApiResponse())
}
