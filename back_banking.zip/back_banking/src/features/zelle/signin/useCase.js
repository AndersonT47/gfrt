import jose from 'node-jose'

import { Result } from '#core/features/index.js'
import { Config } from '#core/config/index.js'



export default class SigninUseCase {
  async execute({ userId, accounts, email, firstName, lastName, ipAddress }) {
    const payload = await this.#createTokenPayload({
      firstName,
      lastName,
      accounts,
      contacts: { email, taxId: userId },
      ipAddress
    })

    const jwe = await this.#signToken({ payload })

    // TODO: Generate an event for Zelle Metrics (APM)

    return Result.ok({
      code: 200,
      message: 'OK',
      value: {
        fiId: Config.get('app.clients.zelleApi.fiId'),
        pid: Config.get('app.clients.zelleApi.pid'),
        ssoUrl: Config.get('app.clients.zelleApi.ssoUrl'),
        jwe
      }
    })
  }

  async #createTokenPayload({ accounts, contacts, firstName, lastName, ipAddress }) {
    const accountsPayload = this.#mapAccountsPayload({ accounts })
    const tokensPayload = this.#mapContactsPayload({ contacts })

    const currentTimeStamp = Math.floor(Date.now() / 1000)
    const expirationTimeStamp = currentTimeStamp + 60 * 24

    const taxId = this.#mapTaxIdPayload({ contacts })

    const payload = {
      acc: accountsPayload,
      tkn: tokensPayload,
      lei: taxId,
      let: 'TaxId',
      // cci: null,
      iat: currentTimeStamp,
      exp: expirationTimeStamp,
      sto: 60 * 24,
      aud: Config.get('app.clients.zelleApi.aud'),
      iss: Config.get('app.clients.zelleApi.iss'),
      firstName,
      lastName,
      streetAddr1: null,
      city: null,
      stateProv: null,
      stateCode: null,
      postalCode: null,
      cntry: null,
      cntryType: null,
      params: [
        {
          id: 'deviceid',
          value: 'a3780051cb118bac'
        },
        {
          id: 'ipaddress',
          value: '10.3.18.186'
        }
      ]
    }

    return payload
  }

  async #signToken({ payload }) {
    const publicKey = Config.get('app.clients.zelleApi.publicKey')

    const keyStore = jose.JWK.createKeyStore()
    const pubKey = await keyStore.add(publicKey, 'pem')

    const buffer = Buffer.from(JSON.stringify(payload))

    const token = await jose.JWE
      .createEncrypt({ format: 'compact' }, pubKey)
      .update(buffer)
      .final()

    console.log({ token, payload: JSON.stringify(payload) })

    return Buffer.from(token, 'utf8').toString('base64')
  }

  #mapAccountsPayload({ accounts }) {
    const env = Config.get('app.clients.zelleApi.env')

    if (env === 'development' || env === 'staging') {
      const accountsPayload = [
        {
          typ: 'S',
          id: 20030
        }
      ]
      return accountsPayload
    }

    const accountsPayload = accounts.map(account => {
      return {
        typ: account.type,
        id: account.number
      }
    })

    return accountsPayload
  }

  #mapContactsPayload({ contacts }) {
    const env = Config.get('app.clients.zelleApi.env')

    if (env === 'development' || env === 'staging') {
      const tokensPayload = [
        {
          typ: 'email',
          id: 'erlon.cabral@foursys.com.br'
        }
      ]
  
      return tokensPayload
    }

    // TODO: In the future extract the phone number and send as well
    const { email } = contacts

    const tokensPayload = [
      {
        typ: 'email',
        id: email
      }
    ]

    return tokensPayload
  }

  #mapTaxIdPayload({ contacts }) {
    const env = Config.get('app.clients.zelleApi.env')

    if (env === 'development' || env === 'staging') {
      return '202009311'
    }

    return contacts?.taxId
  }
}
