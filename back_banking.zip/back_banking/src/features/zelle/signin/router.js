import handler from './endpoint.js'



const schema = {
  description: 'Zelle',
  tags: ['Zelle'],
  summary: '',
  body: {
    type: 'object',
    properties: {
      userId: { type: 'string' },
      accounts: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            accountNumber: { type: 'string' },
            accountType: { type: 'string' }
          }
        }
      },
      email: { type: 'string' },
      firstName: { type: 'string' },
      lastName: { type: 'string' },
      ipAddress: { type: 'string' }
    }
  },
  response: {
    200: {
      type: 'object',
      properties: {
        code: { type: 'integer' },
        message: { type: 'string' },
        data: {
          type: 'object',
          properties: {
            fiId: { type: 'string' },
            pid: { type: 'string' },
            ssoUrl: { type: 'string' },
            jwe: { type: 'string' }
          }
        }
      }
    },
    500: {
      type: 'object',
      properties: {
        code: { type: 'integer' },
        message: { type: 'string' },
        error: { type: 'string' }
      }
    }
  }
}

export default {
  method: 'POST',
  url: '/banking/v1/zelle/signin',
  schema,
  handler
}
