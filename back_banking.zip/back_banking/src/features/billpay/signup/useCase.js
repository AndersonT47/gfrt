import { Result } from '#core/features/index.js'
import { Config } from '#core/config/index.js'
import { useTry } from '#core/hooks/index.js'

import {
  getAuthentication,
  getSsoToken
} from '#core/clients/payrailzApi.js'

import {
  adaptHeadersAuthentication,
  adaptHeadersSso,
  adaptSsoRequestPayload
} from '#core/clients/adapters/payrailzRequestAdapter.js'

import { getAccountInquiry } from '#core/clients/jackhenryApi.js'
import { adaptGetAccountInquiryRequestPayload } from '#core/clients/adapters/jackHenryRequestAdapter.js'

export default class SignupUseCase {
  async execute({ request }) {
    const authenticationBase64 = Config.get('app.clients.payrailzApi.token')
    const headers = adaptHeadersAuthentication(authenticationBase64)
    const [errResult, result] = await useTry(() => getAuthentication(headers))

    if (errResult) {
      return Result.fail({
        code: 500,
        error: errResult.name,
        message: errResult.message
      })
    }

    const { data } = result

    for (const dda of request.body.enrollment.payer.ddas) {
      dda.dda.availBalance = await GetBalance('D', dda.dda.accountNbr)
    }

    const accessToken = data.token.accessToken
    const headersSso = adaptHeadersSso(accessToken)
    const requestSoo = adaptSsoRequestPayload(request.body)

    const [errResultSso, resultSso] = await useTry(() => getSsoToken(requestSoo, headersSso, request.body.enrollment.payer.fspId))

    if (errResultSso) {
      return Result.fail({
        code: errResultSso.response.status,
        error: errResultSso.response.statusText,
        message: errResultSso.response.data.error.message
      })
    }

    return Result.ok({
      code: 200,
      value: resultSso.data
    })
  }
}

async function GetBalance(accountType, accountNumber) {
  const accountInquiryRequest = adaptGetAccountInquiryRequestPayload(accountType, accountNumber)
  const balance = await getAccountInquiry(accountInquiryRequest)
  return balance.data.data.depAcctInqRec.x_DepInfoRec.avlBal.value
}
