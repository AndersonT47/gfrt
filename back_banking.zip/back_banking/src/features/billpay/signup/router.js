import handler from './endpoint.js'

const schema = {
  description: 'BillPay',
  tags: ['BillPay'],
  summary: '',
  params: {
    type: 'object',
    properties: {},
    required: []
  },
  body: {
    enrollment: {
      type: 'object',
      properties: {
        payer: {
          type: 'object',
          properties: {
            fspId: {
              type: 'string',
              description: 'The fspId'
            },
            fspPayerId: {
              type: 'string',
              description:
                'Customer or Member ID assigned by your Financial Service Provider'
            },
            payerType: {
              type: 'string',
              description: 'Payer Type'
            },
            limitType: {
              type: 'string',
              description: 'Limit Type'
            },
            person: {
              type: 'object',
              properties: {
                firstName: {
                  type: 'string',
                  description: 'Person First Name'
                },
                lastName: {
                  type: 'string',
                  description: 'Person Last Name'
                },
                email: {
                  type: 'string',
                  description: 'Person Email'
                },
                mobilePhone: {
                  type: 'string',
                  description: 'Person Mobile Phone'
                }
              }
            },
            organization: {
              type: 'object',
              properties: {
                name: {
                  type: 'string',
                  description: 'Organization name'
                }
              }
            },
            user: {
              type: 'object',
              properties: {
                fspUserId: {
                  type: 'string',
                  description: 'User fspUserId'
                },
                firstName: {
                  type: 'string',
                  description: 'User firstName'
                },
                lastName: {
                  type: 'string',
                  description: 'User lastName'
                }
              }
            },
            payerUser: {
              type: 'object',
              properties: {
                userType: {
                  type: 'string',
                  description: 'PayerUser userType'
                },
                email: {
                  type: 'string',
                  description: 'PayerUser email'
                },
                mobilePhone: {
                  type: 'string',
                  description: 'PayerUser mobilePhone'
                },
                role: {
                  type: 'string',
                  description: 'PayerUser role'
                }
              }
            },
            uspsAddress: {
              type: 'object',
              properties: {
                street1: {
                  type: 'string',
                  description: 'Address street 1'
                },
                city: {
                  type: 'string',
                  description: 'Address City'
                },
                state: {
                  type: 'string',
                  description: 'Address State'
                },
                zip: {
                  type: 'string',
                  description: 'Address Zip Code'
                }
              }
            },

            ddas: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  dda: {
                    type: 'object',
                    properties: {
                      fspDdaId: {
                        type: 'string',
                        description:
                          'DDA ID assigned by your Financial Service Provider '
                      },
                      ddaType: {
                        type: 'string',
                        description: 'DDA Type'
                      },
                      accountNbr: {
                        type: 'string',
                        description: 'DDA account number of Payer'
                      },
                      micrRtn: {
                        type: 'string',
                        description: 'MICR routing number of DDA'
                      },
                      achRtn: {
                        type: 'string',
                        description: 'ACH routing number of DDA'
                      },
                      ddaBillPayFromOffOn: {
                        type: 'string',
                        description:
                          'Indicator of whether or not Bill payment'
                      },
                      ddaP2PPayFromOffOn: {
                        type: 'string',
                        description:
                          'Indicator of whether or not P2P payment can be funded from this DDA'
                      },
                      ddaTransferFromOffOn: {
                        type: 'string',
                        description:
                          'Indicator of whether or not money can be transferred out of this DDA'
                      },
                      ddaTransferToOffOn: {
                        type: 'string',
                        description:
                          'Indicator of whether or not money can be transferred into this DDA'
                      },
                      userDefaultBillPayDdaOffOn: {
                        type: 'string',
                        description:
                          'Indicator for the User’s default funding DDA for bill payments'
                      },
                      userBillPayFromOffOn: {
                        type: 'string',
                        description:
                          'Indicator for the User’s permission to fund Bill Payments'
                      },
                      userP2PPayFromOffOn: {
                        type: 'string',
                        description:
                          'Indicator for the User’s permission to fund P2P Payments from this DDA'
                      },
                      userTransferFromOffOn: {
                        type: 'string',
                        description:
                          'Indicator for the User’s permission to transfer money out of this DDA'
                      },
                      userTransferToOffOn: {
                        type: 'string',
                        description:
                          'Indicator for the User’s permission to transfer money into this DDA'
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  },
  response: {
    200: {
      type: 'object',
      properties: {
        code: { type: 'integer' },
        message: { type: 'string' },
        data: {
          type: 'object',
          properties: {
            payeruserdda: {
              type: 'object',
              properties: {
                sso: {
                  type: 'object',
                  properties: {
                    ssoToken: { type: 'string' },
                    expireSecs: { type: 'number' },
                    uri: { type: 'string' },
                    links: {
                      type: 'array',
                      items: {
                        type: 'object',
                        properties: {
                          offset: { type: 'number' },
                          type: { type: 'string' },
                          defaultUri: { type: 'string' }
                        }
                      }
                    }
                  }
                },
                payer: {
                  type: 'object',
                  properties: {
                    href: { type: 'string' },
                    id: { type: 'number' },
                    fspPayerId: { type: 'string' },
                    fspPayerIdMask: { type: 'string' },
                    payerType: { type: 'string' },
                    status: { type: 'string' },
                    serviceStartOn: { type: 'string' },
                    taxIdMask: { type: 'string' },
                    limitType: { type: 'string' },
                    organization: {
                      type: 'object',
                      properties: {
                        name: { type: 'string' },
                        phone: { type: 'string' },
                        email: { type: 'string' }
                      }
                    },
                    person: {
                      type: 'object',
                      properties: {
                        firstName: { type: 'string' },
                        middleName: { type: 'string' },
                        lastName: { type: 'string' },
                        mobilePhone: { type: 'string' },
                        homePhone: { type: 'string' },
                        workPhone: { type: 'string' },
                        email: { type: 'string' }
                      }
                    },
                    uspsAddress: {
                      type: 'object',
                      properties: {
                        street1: { type: 'string' },
                        street2: { type: 'string' },
                        city: { type: 'string' },
                        state: { type: 'string' },
                        zip: { type: 'string' }
                      }
                    },
                    internationalAddress: {
                      type: 'object',
                      properties: {
                        address1: { type: 'string' },
                        address2: { type: 'string' },
                        address3: { type: 'string' },
                        address4: { type: 'string' },
                        locality: { type: 'string' },
                        adminArea: { type: 'string' },
                        postalCode: { type: 'string' },
                        country: { type: 'string' }
                      }
                    },
                    createdAt: { type: 'string' },
                    updatedAt: { type: 'string' },
                    fsp: {
                      type: 'object',
                      properties: {
                        href: { type: 'string' },
                        id: { type: 'number' }
                      }
                    }
                  }
                },
                user: {
                  type: 'object',
                  properties: {
                    href: { type: 'string' },
                    id: { type: 'number' },
                    fspUserId: { type: 'string' },
                    fspUserIdMask: { type: 'string' },
                    firstName: { type: 'string' },
                    middleName: { type: 'string' },
                    lastName: { type: 'string' },
                    createdAt: { type: 'string' },
                    updatedAt: { type: 'string' }
                  }
                },
                payeruser: {
                  type: 'object',
                  properties: {
                    href: { type: 'string' },
                    id: { type: 'number' },
                    userType: { type: 'string' },
                    mobilePhone: { type: 'string' },
                    homePhone: { type: 'string' },
                    workPhone: { type: 'string' },
                    email: { type: 'string' },
                    language: { type: 'string' },
                    serviceStartOn: { type: 'string' },
                    limitType: { type: 'string' },
                    role: { type: 'string' },
                    otpVerified: { type: 'string' },
                    bpSettingConfirmedAt: { type: 'string' },
                    p2pSettingConfirmedAt: { type: 'string' },
                    a2aSettingConfirmedAt: { type: 'string' },
                    createdAt: { type: 'string' },
                    updatedAt: { type: 'string' }
                  }
                },
                ddauserdda: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      offset: { type: 'number' },
                      href: { type: 'string' },
                      id: { type: 'number' },
                      fspDdaId: { type: 'string' },
                      fspDdaIdMask: { type: 'string' },
                      ddaType: { type: 'string' },
                      accountNbrMask: { type: 'string' },
                      accountSuffix: { type: 'string' },
                      accountMicrNbrMask: { type: 'string' },
                      accountAchNbrMask: { type: 'string' },
                      description: { type: 'string' },
                      nickName: { type: 'string' },
                      accountTitle: { type: 'string' },
                      micrRtn: { type: 'string' },
                      achRtn: { type: 'string' },
                      wireRtn: { type: 'string' },
                      ledgerBalance: { type: 'string' },
                      availBalance: { type: 'string' },
                      ddaBillPayFromOffOn: { type: 'string' },
                      ddaP2PPayFromOffOn: { type: 'string' },
                      ddaTransferFromOffOn: { type: 'string' },
                      ddaTransferToOffOn: { type: 'string' },
                      ddaA2AInternalFromOffOn: { type: 'string' },
                      ddaA2AInternalToOffOn: { type: 'string' },
                      uspsAddress: {
                        type: 'object',
                        properties: {
                          street1: { type: 'string' },
                          street2: { type: 'string' },
                          city: { type: 'string' },
                          state: { type: 'string' },
                          zip: { type: 'string' }
                        }
                      },
                      userDefaultBillPayDdaOffOn: { type: 'string' },
                      userBillPayFromOffOn: { type: 'string' },
                      userP2PPayFromOffOn: { type: 'string' },
                      userTransferFromOffOn: { type: 'string' },
                      userTransferToOffOn: { type: 'string' },
                      userA2AInternalFromOffOn: { type: 'string' },
                      userA2AInternalToOffOn: { type: 'string' },
                      createdAt: { type: 'string' },
                      updatedAt: { type: 'string' }
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    500: {
      type: 'object',
      properties: {
        code: { type: 'integer' },
        message: { type: 'string' },
        error: { type: 'string' }
      }
    }
  }
}

export default {
  method: 'POST',
  url: '/banking/v1/billpay/signup',
  schema,
  handler
}
