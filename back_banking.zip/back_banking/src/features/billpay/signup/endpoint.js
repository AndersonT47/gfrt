import { UseCaseHandler } from '#core/features/index.js'
import SignupUseCase from './useCase.js'

export default async function signupEndpoint(request, reply) {
  const useCase = new SignupUseCase()
  const result = await UseCaseHandler.dispatch(useCase, { request })

  return reply
    .status(result.code)
    .send(result.toApiResponse())
}
