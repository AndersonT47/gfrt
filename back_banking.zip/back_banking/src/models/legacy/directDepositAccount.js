import { safeToString, safeTrim, usingPipe } from '#core/utils/index.js'

import {
  connectToSafraOfficeBankDb,
  executeStoreProcedure
} from '#core/database/mssql/index.js'

export async function findByCif(cif) {
  const connection = await connectToSafraOfficeBankDb()
  const recordset = await executeStoreProcedure(connection, 'SP_DDA_GET_ACCT', { cif })

  return recordset.map(record => {
    const accountType = safeTrim(record.ACTYPE)
    const accountNumber = usingPipe(record.ACCTNO, safeToString, safeTrim)

    return {
      accountType,
      accountNumber
    }
  })
}

export async function findAccountContactsByCif(cif) {
  const connection = await connectToSafraOfficeBankDb()
  const recordset = await executeStoreProcedure(connection, 'SP_DDA_GET_CIFCONTACT', { cif })

  if (recordset?.length === 0) return undefined

  const [contact] = recordset

  const email = safeTrim(contact.EMAIL)
  const mobilePhoneNumber = safeTrim(contact.mobile)
  const taxId = safeTrim(contact.taxssn)
  const firstName = safeTrim(contact.firstName)
  const lastName = safeTrim(contact.lastName)

  return {
    email,
    mobilePhoneNumber,
    taxId,
    firstName,
    lastName
  }
}
