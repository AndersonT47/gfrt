import { connectToSafraOfficeBankDb, queryFirst } from '#core/database/mssql/index.js'

export async function getIdtUser(idtUserToken, cifToken, cifIdtUser) {
  if (cifToken === cifIdtUser) {
    return {
      IdtUser: idtUserToken
    }
  }

  const query = `
    select idtuser2 IdtUser from ib.relatedidtcifusers
    where idtuser1=@idtuser1
    and idtcif1=@idtcif1
    and idtcif2=@idtcif2
    and active=1
    union
    select idtuser1 IdtUser from ib.relatedidtcifusers
    where idtuser2=@idtuser1
    and idtcif2=@idtcif1
    and idtcif1=@idtcif2
    and active=1`

  const connection = await connectToSafraOfficeBankDb()

  const request = connection.request()
  request.input('idtuser1', idtUserToken)
  request.input('idtcif1', cifToken)
  request.input('idtcif2', cifIdtUser)

  const record = await queryFirst(request, query)

  if (!record) {
    return undefined
  }

  const { IdtUser } = record

  return {
    IdtUser
  }
}
