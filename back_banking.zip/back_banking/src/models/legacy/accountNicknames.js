import { safeTrim, safeToString, usingPipe } from '#core/utils/index.js'

import {
  connectToSafraOfficeBankDb,
  executeStoreProcedure
} from '#core/database/mssql/index.js'

export async function findAccountsCDByCif(cif) {
  const connection = await connectToSafraOfficeBankDb()
  const recordset = await executeStoreProcedure(connection, 'sp_CD_account_sum_V2', { cif })

  return recordset.map(record => {
    const accountNumber = usingPipe(record.ACCTNO, safeToString, safeTrim)
    const accountNickname = record.NICKNAME
    const accountDescription = safeTrim(record.JHADSC)

    return {
      accountNumber,
      accountNickname,
      accountDescription,
      acctType: 'CD'
    }
  })
}

export async function findAccountsDDByCif(cif) {
  const connection = await connectToSafraOfficeBankDb()
  const recordset = await executeStoreProcedure(connection, 'sp_DDA_ACCOUNT_SUM_V2', { cif })

  return recordset.map(record => {
    const accountNumber = usingPipe(record.ACCTNO, safeToString, safeTrim)
    const accountNickname = record.NICKNAME
    const accountDescription = safeTrim(record.JHADSC)

    return {
      accountNumber,
      accountNickname,
      accountDescription,
      acctType: 'DD'
    }
  })
}

export async function findAccountsFCByCif(cif) {
  const connection = await connectToSafraOfficeBankDb()
  const recordset = await executeStoreProcedure(connection, 'SP_FC_ACCOUNT_SUM_V2', { cif })

  return recordset.map(record => {
    const accountNumber = usingPipe(record.ACCTNO, safeToString, safeTrim)
    const accountNickname = record.NICKNAME
    const accountDescription = safeTrim(record.JHADSC)

    return {
      accountNumber,
      accountNickname,
      accountDescription,
      acctType: 'FC'
    }
  })
}

export async function findAccountsLNByCif(cif) {
  const connection = await connectToSafraOfficeBankDb()
  const recordset = await executeStoreProcedure(connection, 'SP_LOAN_ACCOUNT_SUM_V2', { cif })

  return recordset.map(record => {
    const accountNumber = usingPipe(record.ACCTNO, safeToString, safeTrim)
    const accountNickname = record.NICKNAME
    const accountDescription = safeTrim(record.JHADSC)

    return {
      accountNumber,
      accountNickname,
      accountDescription,
      acctType: 'LN'
    }
  })
}

export async function findAccountsLCByCif(cif) {
  const connection = await connectToSafraOfficeBankDb()
  const recordset = await executeStoreProcedure(connection, 'SP_LOAN_ACCOUNT_SUM_LC_V2', { cif })

  return recordset.map(record => {
    const accountNumber = usingPipe(record.ACCTNO, safeToString, safeTrim)
    const accountNickname = record.NICKNAME
    const accountDescription = safeTrim(record.JHADSC)

    return {
      accountNumber,
      accountNickname,
      accountDescription,
      acctType: 'LC'
    }
  })
}

export async function findAccountsSCByCif(cif) {
  const connection = await connectToSafraOfficeBankDb()
  const recordset = await executeStoreProcedure(connection, 'SP_SEC_ACCOUNT_SUM_V2', { cif })

  const recordsetFiltered = recordset.filter((account, index, accounts) => index === accounts.findIndex((x) => (x.ACCTNO === account.ACCTNO)))

  return recordsetFiltered.map(record => {
    const accountNumber = usingPipe(record.ACCTNO, safeToString, safeTrim)
    const accountNickname = record.NICKNAME
    const accountDescription = null

    return {
      accountNumber,
      accountNickname,
      accountDescription,
      acctType: 'SC'
    }
  })
}

export async function findAccountsBKByCif(cif) {
  const connection = await connectToSafraOfficeBankDb()
  const recordset = await executeStoreProcedure(connection, 'SP_SEC_ACCOUNT_SUM_189_IB_V2', { cif })

  const recordsetFiltered = recordset.filter((account, index, accounts) => index === accounts.findIndex((x) => (x.ACCTNO === account.ACCTNO)))

  return recordsetFiltered.map(record => {
    const accountNumber = usingPipe(record.ACCTNO, safeToString, safeTrim)
    const accountNickname = record.NICKNAME
    const accountDescription = safeTrim(record.BR_ACCT_TYPE_DESCRIPTION)
    const accountBkType = record.isJSAM === 1 ? 'IS' : 'TI'

    return {
      accountNumber,
      accountNickname,
      accountDescription,
      acctType: 'BK',
      accountBkType
    }
  })
}

export async function findAccountsFXByCif(cif) {
  const connection = await connectToSafraOfficeBankDb()
  const recordset = await executeStoreProcedure(connection, 'sp_FX_Sum_v2', { cifno: cif })

  return recordset.map(record => {
    const accountNumber = usingPipe(record.Ctpt_ID, safeToString, safeTrim)
    const accountNickname = record.NICKNAME
    const accountDescription = 'FX'

    return {
      accountNumber,
      accountNickname,
      accountDescription,
      acctType: 'FX'
    }
  })
}
