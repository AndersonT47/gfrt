import { prisma } from '#core/database/prisma/index.js'

export async function findByNickname(account) {
  return prisma.ACCT_NICKNAME.findFirst({
    where: {
      ACCTNO: account.accountNumber,
      ACCTTYPE: account.acctType
    }
  })
}

export async function createNickname(account) {
  return prisma.ACCT_NICKNAME.create({
    data: {
      ACCTNO: account.accountNumber,
      Nickname: account.accountNickname,
      ACCTTYPE: account.acctType
    }
  })
}

export async function updateNickname(account) {
  return prisma.ACCT_NICKNAME.update({
    where: {
      ID: account.ID
    },
    data: {
      Nickname: account.accountNickname
    }
  })
}
