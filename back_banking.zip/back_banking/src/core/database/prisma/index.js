import { PrismaClient } from '@prisma/client'

import { Config } from '#core/config/index.js'

export const prisma = new PrismaClient({
  datasourceUrl: Config.get('app.databaseUrl')
})
