import mssql from 'mssql'

import { Config } from '#core/config/index.js'

export async function connectToSafraOfficeBankDb() {
  const { ...props } = Config.get('app.legacy.sqlServer.safraOfficeBank')

  const config = {
    ...props,
    options: {
      encrypt: false,
      trustServerCertificate: true
    }
  }

  return mssql.connect(config)
}

export async function executeStoreProcedure(connection, query, parameters = {}) {
  const request = connection.request()

  for (const key of Object.keys(parameters)) {
    request.input(key, parameters[key])
  }

  const { recordset } = await request.execute(query)

  await connection.close()

  if (recordset?.length === 0) return []

  return recordset
}

export async function queryFirst(connection, queryString) {
  const { recordset: resultSet } = await connection.query(queryString)

  if (!resultSet || resultSet?.length === 0) return undefined

  const firstRecord = resultSet[0]

  if (!firstRecord) return undefined

  return firstRecord
}
