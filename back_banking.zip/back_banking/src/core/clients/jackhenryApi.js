import https from 'https'
import axios from 'axios'

import { Config } from '#core/config/index.js'

const httpsAgent = new https.Agent({ rejectUnauthorized: false })

const httpClientJackhenry = axios.create({
  httpsAgent,
  baseURL: Config.get('app.clients.jackhenryApi.baseUrl')
})

export async function getAccountInquiry(request) {
  return httpClientJackhenry.post('/v1/inquiries/accounts/inquiry', request)
}
