export function adaptHeadersAuthentication(authentication) {
  return {
    Authorization: `Basic ${authentication}`,
    Accept: 'application/vnd.payrailz.api+json; version=v1',
    'Content-Type': 'application/json'
  }
}

export function adaptHeadersSso(token) {
  return {
    Authorization: `Bearer ${token}`,
    Accept: 'application/vnd.payrailz.api+json; version=v1',
    'Content-Type': 'application/json'
  }
}

export function adaptSsoRequestPayload(request) {
  const { fspId, ...payload } = request.enrollment.payer
  return {
    payer: payload
  }
}
