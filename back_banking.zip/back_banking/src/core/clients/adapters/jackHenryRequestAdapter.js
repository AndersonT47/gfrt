export function adaptGetAccountInquiryRequestPayload(accountType, accountNumber) {
  return {
    inAcctId: {
      acctId: {
        value: accountNumber
      },
      acctType: {
        value: accountType
      }
    },
    incXtendElemArray: [
      {
        xtendElem: {
          value: 'x_DepStmtInfo'
        }
      },
      {
        xtendElem: {
          value: 'x_DepInfoRec'
        }
      },
      {
        xtendElem: {
          value: 'x_DepBalDtInfo'
        }
      },
      {
        xtendElem: {
          value: 'x_DepAcctInfo'
        }
      },
      {
        xtendElem: {
          value: 'x_DepNSFODInfo'
        }
      }
    ]
  }
}
