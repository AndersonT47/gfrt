import axios from 'axios'
import { Config } from '#core/config/index.js'

const httpClientPayrailz = axios.create({
  baseURL: Config.get('app.clients.payrailzApi.baseUrl')
})

export async function getAuthentication(headers) {
  return httpClientPayrailz.post('/oauth2/tokens?grant_type=client_credentials', null, { headers })
}

export async function getSsoToken(request, headers, fspId) {
  return httpClientPayrailz.post(`/fsps/${fspId}/payeruserddas?sso=on`, request, { headers })
}
