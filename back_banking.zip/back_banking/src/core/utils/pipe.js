export const pipe = (...functions) => input => functions.reduce((value, func) => func(value), input)

export const usingPipe = (input, ...functions) => pipe(...functions)(input)
