export function safeTrim(value) {
  if (value === null || value === undefined || typeof value !== 'string') return undefined
  return value?.trim()
}

export function safeToString(value) {
  if (typeof value !== 'string') return value?.toString()
  return value
}
