import { Result } from '#core/features/index.js'
import { useTry } from '#core/hooks/index.js'
import { randomUUID } from 'crypto'
import { Logger } from '#core/logging/index.js'

export class UseCaseHandler {
  static async dispatch(useCase, params) {
    if (!useCase || typeof useCase.execute !== 'function') {
      return Result.fail({ code: 500, error: 'Internal Server Error', message: 'Something went wrong' })
    }
    const [error, result] = await useTry(() => useCase.execute(params))
    if (error) return await this.#dispatchError(error)
    return result
  }

  static async #dispatchError(error) {
    const requestId = randomUUID()
    Logger.error('Error ' + requestId, error)
    Logger.error(error)
    return Result.fail({
      code: 500,
      error: 'Internal Server Error',
      message: 'Something went wrong. Please contact the support! (ErrorCode: ' + requestId + ')'
    })
  }
}
