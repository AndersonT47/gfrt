import { ApiResponse } from '#core/http/index.js'

export class Result {
  isSuccess
  isFailure
  code
  error
  message
  errorDetail
  value

  constructor({ isSuccess, code, error, message, value }) {
    if (isSuccess && error) throw new Error('InvalidOperation: A result cannot be successful and contain an error')
    if (!isSuccess && !error) throw new Error('InvalidOperation: A failing result needs to contain an error message')
    this.isSuccess = isSuccess
    this.isFailure = !isSuccess
    this.code = code
    this.error = error
    this.message = message
    this.value = value
    this.errorDetail = { details: [] }
    Object.freeze(this)
  }

  addErrorDetail({ id, message }) {
    this.errorDetail.details.push({ id, message })
    return this
  }

  hasErrorDetails() {
    return this.errorDetail?.details?.length > 0
  }

  toApiResponse() {
    return ApiResponse.createResponse({
      code: this.code,
      error: this.error,
      message: this.message,
      data: this.value,
      errorDetail: this.errorDetail?.details?.length === 0 ? undefined : this.errorDetail
    })
  }

  static ok({ code = 200, value }) {
    return new Result({ isSuccess: true, code, value, message: 'OK' })
  }

  static fail({ code = 500, error, message }) {
    return new Result({ isSuccess: false, code, error, message })
  }

  static combine(results) {
    for (const result of results) {
      if (result.isFailure) return result
    }
    return Result.ok({ code: 200, value: {} })
  }
}
