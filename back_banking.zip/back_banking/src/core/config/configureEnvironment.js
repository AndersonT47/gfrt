const splitArrayBy = (array, separator) => array.split(separator)

const convertToLocaleLowerCase = (item) => item[0].toLocaleLowerCase() + item.slice(1)

const setValuesFromObject = (lastIndex, value, environment) => (obj, item, index) => {
  if (obj[item] === undefined) {
    obj[item] = {}
  }
  if (lastIndex === index) {
    obj[item] = value
    return environment
  }
  return obj[item]
}

export const configureEnvironmentConfigServer = (environment, obj, separator, configServer) => {
  return Object.keys(obj).reduce((env, property) => {
    const propertiersLowerCase = splitArrayBy(property, separator).map(convertToLocaleLowerCase)
    const lastIndex = propertiersLowerCase.length - 1
    const value = configServer.get(property)

    return propertiersLowerCase.reduce(setValuesFromObject(lastIndex, value, env), env)
  }, environment)
}
