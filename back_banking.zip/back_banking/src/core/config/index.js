import path from 'path'
import fs from 'fs'
import configServer from 'nice-cloud-config-client'
import yaml from 'js-yaml'

import { configureEnvironmentConfigServer } from './configureEnvironment.js'
import { createLogger } from '../logging/index.js'

export class Config {
  #env
  #logger

  constructor(env = process.env.NODE_ENV) {
    this.#env = env || 'Local'
    this.#logger = createLogger({})
  }

  async bootstrap() {
    this.#logger.info('Starting configuration for env: ' + this.#env)

    const configMap = new Map()
    configMap.set('local', this.#loadEnvFromFile.bind(this))
    configMap.set('development', this.#loadFromConfigServer.bind(this))
    configMap.set('staging', this.#loadFromConfigServer.bind(this))
    configMap.set('production', this.#loadFromConfigServer.bind(this))

    const loadConfigFunction = configMap.get(this.#env.toLowerCase())
    const config = await loadConfigFunction()

    Object.freeze(config)
    this.#logger = createLogger(config)

    return config
  }

  async #loadEnvFromFile() {
    const filePath = '.env.yml'
    const absolutePath = path.resolve(path.dirname(''), filePath)

    this.#logger.info('Loading env using file ' + absolutePath)

    if (!fs.existsSync(absolutePath)) {
      throw new Error('No env file was found')
    }

    const fileContent = fs.readFileSync(absolutePath, { encoding: 'utf-8' })
    const parsedConfig = yaml.load(fileContent)

    return parsedConfig
  }

  async #loadFromConfigServer() {
    const appName = process.env.CONFIG_SERVER_APP_NAME
    const serverUrl = process.env.CONFIG_SERVER_URL
    const user = process.env.CONFIG_SERVER_USER
    const password = process.env.CONFIG_SERVER_PASSWORD

    if (!appName) throw new Error('Application name must be provided')
    if (!serverUrl) throw new Error('Config server url must be provided')
    if (!user) throw new Error('Config server user must be provided')
    if (!password) throw new Error('Config server password must be provided')

    this.#logger.info('Loading env using config server ' + serverUrl)

    const configFromServer = await configServer.load({
      rejectUnauthorized: false,
      name: appName,
      endpoint: serverUrl,
      profiles: this.#env,
      auth: {
        user,
        pass: password
      }
    })

    if (configFromServer instanceof Error) throw configFromServer

    const config = {}
    return configureEnvironmentConfigServer(config, configFromServer.properties, '.', configFromServer)
  }

  static get(key) {
    return key.split('.').reduce((acc, curr) => acc?.[curr], global.environment)
  }

  logger() {
    return this.#logger
  }
}
