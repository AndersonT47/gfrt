export class ApiResponse {
  constructor({ code, data, error, message, errorDetail }) {
    this.code = code
    this.data = data
    this.error = error
    this.message = message
    this.errorDetail = errorDetail
  }

  static createResponse({ code, data, error, message, errorDetail }) {
    return Object.freeze(new ApiResponse({ code, data, error, message, errorDetail }))
  }
}
