import pino from 'pino'
import { getCurrentDateTimeFormatted } from '../utils/time.js'

export const createLogger = (_config) => {
  const streams = []
  const loggingConfig = _config?.app?.logging
  const stdoutStream = loggingConfig?.streams?.stdout
  const fileStream = loggingConfig?.streams?.file

  if (stdoutStream?.enabled) {
    streams.push({ stream: process.stdout })
  }

  if (fileStream?.enabled) {
    streams.push({ stream: pino.destination(fileStream.path) })
  }

  const redactFields = ['headers.authorization']
  const redactConfig = loggingConfig?.redact?.split(',')?.map(field => field?.trim())?.filter(field => field !== '')

  if (redactConfig && redactConfig.length > 0) {
    redactFields.push(...redactConfig)
  }

  const loggerConfig = {
    level: loggingConfig?.level || 'debug',
    redact: redactFields,
    formatters: {
      level: level => ({ level: level.toUpperCase() })
    },
    timestamp: () => {
      return `,"time":"${getCurrentDateTimeFormatted()}"`
    }
  }

  return pino(loggerConfig, pino.multistream(streams))
}

export class Logger {
  static get current() {
    return global.logger
  }

  static info(message, ...args) {
    return this.current.info(message, ...args)
  }

  static error(message, ...args) {
    return this.current.error(message, ...args)
  }
}
