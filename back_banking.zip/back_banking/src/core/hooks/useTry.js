export async function useTry(asyncFunction) {
  try {
    const result = await asyncFunction()
    return [null, result]
  } catch (error) {
    if (error instanceof Error) {
      return [error, null]
    }
    return [new Error(error?.message), null]
  }
}
