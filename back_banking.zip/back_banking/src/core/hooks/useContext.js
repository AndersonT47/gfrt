import AsyncHooks from 'node:async_hooks'

const store = new Map()
const asyncHook = AsyncHooks.createHook({
  init: (_0x10d4cd, _0x5f54ad, _0x22bf0b) => {
    if (store.has(_0x22bf0b)) {
      store.set(_0x10d4cd, store.get(_0x22bf0b))
    }
  },
  destroy: _0x42a743 => {
    if (store.has(_0x42a743)) {
      store.delete(_0x42a743)
    }
  }
})

asyncHook.enable()

export function initContext(callback) {
  const executionId = AsyncHooks.executionAsyncId()
  store.set(executionId, {})
  return callback(store.get(executionId))
}

export function useContext() {
  const executionId = AsyncHooks.executionAsyncId()
  const context = store.get(executionId)
  return context || {}
}
