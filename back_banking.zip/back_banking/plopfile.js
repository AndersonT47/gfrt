export default function (plop) {
  plop.setGenerator('feature', {
    description: 'Create a new feature',
    prompts: [
      {
        type: 'input',
        name: 'name',
        message: 'What is your feature name?'
      }
    ],
    actions: [
      {
        type: 'addMany',
        destination: './src/features/{{camelCase name}}',
        templateFiles: './templates/feature/*.hbs',
        base: './templates/feature'
      }
    ]
  })

  plop.setGenerator('middleware', {
    description: 'Create a new api middleware',
    prompts: [
      {
        type: 'input',
        name: 'name',
        message: 'What is your middleware name?'
      }
    ],
    actions: [
      {
        type: 'add',
        path: './src/app/api/middlewares/{{camelCase name}}.js',
        templateFile: './templates/api/middleware/middleware.js.hbs'
      }
    ]
  })

  plop.setGenerator('worker', {
    description: 'Create a new worker',
    prompts: [
      {
        type: 'input',
        name: 'name',
        message: 'What is your worker consumer name?'
      },
      {
        type: 'list',
        name: 'workerType',
        message: 'What is the type of your consumer?',
        choices: ['kafka', 'rabbitmq']
      }
    ],
    actions: [
      {
        type: 'add',
        path: './src/app/worker/{{camelCase name}}Consumer.js',
        templateFile:
          './templates/worker/{{lowerCase workerType}}/consumer.js.hbs'
      }
    ]
  })
}
