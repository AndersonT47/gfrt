#!/bin/sh

npx nodemon -r dotenv/config ./src/app/api/index.js | pino-pretty;
