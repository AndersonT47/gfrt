#!/bin/sh

npx nodemon -r dotenv/config ./src/app/worker/index.js -- $1 | pino-pretty;
